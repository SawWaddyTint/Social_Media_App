import 'dart:io';
import 'dart:typed_data';

import 'package:social_media_app/data/vos/news_feed_vo.dart';

abstract class SocialModel {
  Stream<List<NewsFeedVO>> getNewsFeed();
  Future<void> addNewPost(String description, File? imageFile);
  Future<void> editPost(NewsFeedVO newsFeed,File? imageFile);
  Future<void> deletePost(int postId);
  Stream<NewsFeedVO> getNewsFeedById(int newsFeedId);
}
