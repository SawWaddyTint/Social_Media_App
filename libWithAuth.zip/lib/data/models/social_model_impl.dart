import 'dart:io';

import 'package:socialmedia/data/models/authentication_model.dart';
import 'package:socialmedia/data/models/authentication_model_impl.dart';
import 'package:socialmedia/data/models/social_model.dart';
import 'package:socialmedia/data/vos/news_feed_vo.dart';
import 'package:socialmedia/network/cloud_firestore_data_agent_impl.dart';
import 'package:socialmedia/network/real_time_database_data_agent_impl.dart';
import 'package:socialmedia/network/social_data_agent.dart';

class SocialModelImpl extends SocialModel {
  @override
  static final SocialModelImpl _singleton = SocialModelImpl._internal();

  factory SocialModelImpl() {
    return _singleton;
  }

  SocialModelImpl._internal();

  //SocialDataAgent mDataAgent = RealtimeDatabaseDataAgentImpl();
  SocialDataAgent mDataAgent = CloudFireStoreDataAgentImpl();

  /// Auth Models
  final AuthenticationModel _authenticationModel = AuthenticationModelImpl();

  Stream<List<NewsFeedVO>> getNewsFeed() {
    return mDataAgent.getNewsFeed();
  }

  @override
  Stream<NewsFeedVO> getNewsFeedbyId(int newsFeedId) {
    return mDataAgent.getNewsFeedById(newsFeedId);
  }

  @override
  Future<void> addNewPost(String description, File? imageFile) {
    if (imageFile != null) {
      return mDataAgent.uploadFileToFirebase(imageFile).then((imageUrl) {
        craftNewsFeed(description, imageUrl).then((newsPost) {
          mDataAgent.addNewPost(newsPost);
        });
      });
    } else {
      return craftNewsFeed(description, "").then((newsPost) {
        mDataAgent.addNewPost(newsPost);
      });
    }
  }

  Future<NewsFeedVO> craftNewsFeed(String description, String imageUrl) {
    var currentMilliSecond = DateTime.now().millisecondsSinceEpoch;
    var newsPost = NewsFeedVO(
        currentMilliSecond,
        description,
        "https://i.pinimg.com/474x/87/be/16/87be1686157a356132813070bbb1c027.jpg",
        _authenticationModel.getLogInUser().userName,
        imageUrl);
    return Future.value(newsPost);
  }

  @override
  Future<void> deletePost(int postId) {
    return mDataAgent.deletePost(postId);
  }

  @override
  Future<void> editPost(NewsFeedVO newsFeed, File? imageFile) {
    return mDataAgent.addNewPost(newsFeed);
  }
}
