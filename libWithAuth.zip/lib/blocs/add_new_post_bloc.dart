import 'dart:io';

import 'package:flutter/material.dart';
import 'package:socialmedia/data/models/authentication_model.dart';
import 'package:socialmedia/data/models/authentication_model_impl.dart';
import 'package:socialmedia/data/models/social_model.dart';
import 'package:socialmedia/data/models/social_model_impl.dart';
import 'package:socialmedia/data/vos/news_feed_vo.dart';
import 'package:socialmedia/data/vos/user_vo.dart';

class AddNewPostBloc extends ChangeNotifier {
  /// State
  String newPostDescription = "";
  bool isAddNewPostError = false;
  bool isDisposed = false;
  bool isLoading = false;
  UserVO? _loggedInUser;

  /// Model
  final SocialModel _model = SocialModelImpl();
  final AuthenticationModel _mAuthenticationModel = AuthenticationModelImpl();

  ///Image
  File? chosenImageFile;

  /// For Edit Mode
  bool isInEditMode = false;
  String userName = "";
  String profilePicture = "";
  NewsFeedVO? mNewsFeed;

  AddNewPostBloc({int? newsFeedId}) {
    _loggedInUser = _mAuthenticationModel.getLogInUser();
    if (newsFeedId != null) {
      isInEditMode = true;
      _prepopulateDataForEditMode(newsFeedId);
    } else {
      _prepopulateDataForAddNewPost();
    }
  }

  void onImageChosen(File choseFile) {
    chosenImageFile = choseFile;
    _notifySafely();
  }

  void _prepopulateDataForAddNewPost() {
    userName = _mAuthenticationModel.getLogInUser().userName ?? "";
    profilePicture =
        "https://i.pinimg.com/474x/87/be/16/87be1686157a356132813070bbb1c027.jpg";
    _notifySafely();
  }

  void _prepopulateDataForEditMode(int newsFeedId) {
    _model.getNewsFeedbyId(newsFeedId).listen((newsFeed) {
      userName = newsFeed.userName ?? "";
      profilePicture = newsFeed.profilePicture ?? "";
      newPostDescription = newsFeed.description ?? "";
      mNewsFeed = newsFeed;
      _notifySafely();
    });
  }

  void onTapDeleteImage() {
    chosenImageFile = null;
    _notifySafely();
  }

  void onNewPostTextChanged(String newPostDescription) {
    this.newPostDescription = newPostDescription;
  }

  Future onTapAddNewPost() {
    if (newPostDescription.isEmpty) {
      isAddNewPostError = true;
      _notifySafely();
      return Future.error("Error");
    } else {
      isAddNewPostError = false;
      _notifySafely();
      isLoading = true;
      _notifySafely();
      if (isInEditMode) {
        return _editNewsFeedPost().then((value) {
          isLoading = false;
          _notifySafely();
        });
      } else {
        return _createNewsFeedPost().then((value) {
          isLoading = false;
          _notifySafely();
        });
      }
    }
  }

  Future<void> _editNewsFeedPost() {
    mNewsFeed?.description = newPostDescription;
    if (mNewsFeed != null) {
      return _model.editPost(mNewsFeed!, chosenImageFile);
    } else {
      return Future.error("Error");
    }
  }

  Future<void> _createNewsFeedPost() {
    return _model.addNewPost(newPostDescription, chosenImageFile);
  }

  void _notifySafely() {
    if (!isDisposed) {
      notifyListeners();
    }
  }

  @override
  void dispose() {
    super.dispose();
    isDisposed = true;
  }
}
